(function(){function e(e){return e.state===`interrupted`||e.hasMoreHistory===!0||e.completenessStatus===`partial`?`partial`:e.completenessStatus===`unknown`?`unknown`:e.isComplete===!0||e.completenessStatus===`complete`?`complete`:`partial`}function t(t){if(!t||!Array.isArray(t.messages)||t.messages.length===0)throw Error(`Captured conversation contains no messages to export.`);let n=t.messages.filter(e=>e&&(e.role===`user`||e.role===`assistant`)&&typeof e.content==`string`&&e.content.trim().length>0);if(n.length===0)throw Error(`Captured conversation contains no valid user or assistant messages to export.`);let r=e(t),i=t.id&&t.id!==`provisional-tab`&&t.id!==`new-chat`?t.id:null,a=n.map((e,t)=>({id:e.id||`msg-${t+1}`,sequence:t+1,role:e.role,content:e.content,timestamp:e.timestamp??null,sourceMessageId:e.sourceMessageId??null}));return{format:`voidzone-raw-conversation`,version:`1.0`,conversationId:i,sourcePlatform:(t.platform||`chatgpt`).toLowerCase().trim(),conversationTitle:(t.title||`Captured conversation`).trim(),exportedAt:new Date().toISOString(),captureCompleteness:r,messageCount:a.length,messages:a}}function n(e,t){let n=(e||`voidzone-conversation`).toLowerCase().replace(/[/\\?%*:|"<>]/g,``).replace(/\s+/g,`-`).replace(/-+/g,`-`).replace(/^-|-$/g,``).slice(0,40);return`${n.length>0?n:`voidzone-conversation`}${t?`-${t.replace(/[^a-zA-Z0-9_-]/g,``).slice(0,8)}`:``}-raw.json`}function r(e){return JSON.stringify(e,null,2)}var i=`https://claude.ai/new`;function a(e){return(e||``).toLowerCase().replace(/[.,/#!$%^&*;:{}=\-_`~()?"'’]/g,` `).replace(/\s+/g,` `).trim()}function o(e){let t=a(e);return t===`hey beru`||t===`hi beru`||t===`hello beru`||t===`ok beru`||t===`okay beru`||t===`beru`}function s(e){let t=a(e);for(let e of[`hey beru`,`hi beru`,`hello beru`,`ok beru`,`okay beru`,`beru`]){if(t===e)return``;if(t.startsWith(`${e} `))return t.slice(e.length+1).trim()}return t}function c(e){let t=e||``,n=a(t);if(!n)return{type:`general_query`,rawInput:t,cleanedText:``,query:``};if(o(n))return{type:`wake_word`,rawInput:t,cleanedText:n};let r=s(n);return r?[`stop listening`,`stop`,`cancel`,`cancel that`,`mute`,`be quiet`,`never mind`].some(e=>r===e||r.startsWith(`${e} `))?{type:`stop_listening`,rawInput:t,cleanedText:n}:[`get me the chat file`,`get the chat file`,`get my chat file`,`get chat file`,`download me the chat file`,`download the chat file`,`download my chat file`,`download chat file`,`download this chat`,`download conversation`,`download this conversation`,`get conversation file`,`get conversation`,`export chat file`,`export conversation`,`save chat file`].some(e=>r===e||r.includes(e))?{type:`get_chat_file`,rawInput:t,cleanedText:n}:[`give this file to claude`,`give the file to claude`,`give file to claude`,`give this to claude`,`transfer this file to claude`,`transfer this to claude`,`transfer to claude`,`send this file to claude`,`send this to claude`,`send to claude`,`open this in claude`,`open claude`,`open a new claude chat`,`open a new claude conversation`,`pass this to claude`].some(e=>r===e||r.includes(e))?{type:`transfer_to_claude`,rawInput:t,cleanedText:n}:{type:`general_query`,rawInput:t,cleanedText:n,query:r||t}:{type:`wake_word`,rawInput:t,cleanedText:n}}function l(e){if(!e||!Array.isArray(e.messages)||e.messages.length===0)throw Error(`Cannot format Claude continuation prompt: Export contains no messages.`);let t=[`You are continuing a project previously discussed in another AI session. Below is the verified conversation transcript from the previous session:`,``,`=== PREVIOUS CONVERSATION: ${e.conversationTitle||`Untitled Session`} ===`,`Source Platform: ${(e.sourcePlatform||`chatgpt`).toUpperCase()}`,`Exported At: ${e.exportedAt||new Date().toISOString()}`,`Completeness: ${e.captureCompleteness.toUpperCase()}`,`Message Count: ${e.messageCount}`,``,`--- TRANSCRIPT BEGIN ---`];for(let n of e.messages){let e=n.role===`user`?`User`:`Assistant`,r=n.timestamp?` [${n.timestamp}]`:``;t.push(`${e}${r}:`),t.push(n.content),t.push(``)}return t.push(`--- TRANSCRIPT END ---`),t.push(``),t.push(`Please review the preceding transcript and continue assisting me with our project from our last point of discussion.`),t.join(`
`)}function u(e,i=!0){if(!e||!Array.isArray(e.messages)||e.messages.length===0)return{success:!1,message:`No captured conversation found. Please ensure ChatGPT is active and messages have been captured.`,spokenText:`I couldn't retrieve the current conversation. Please make sure you have an active ChatGPT session captured.`};try{let a=t(e),o=r(a),s=n(a.conversationTitle,a.conversationId);if(i&&typeof document<`u`){let e=new Blob([o],{type:`application/json`}),t=URL.createObjectURL(e),n=document.createElement(`a`);n.href=t,n.download=s,document.body.appendChild(n),n.click(),setTimeout(()=>{n.parentNode&&document.body.removeChild(n),URL.revokeObjectURL(t)},1e3)}return{success:!0,exportData:a,jsonString:o,filename:s,message:`Conversation file ready: ${s} (${a.messageCount} messages).`,spokenText:`Your conversation file is ready. I've downloaded ${s}.`}}catch(e){return{success:!1,message:e instanceof Error?e.message:`Failed to create conversation export.`,spokenText:`I couldn't generate the chat file due to an error.`}}}async function d(e,t=!0){if(!e||!Array.isArray(e.messages)||e.messages.length===0)return{success:!1,continuationPrompt:``,targetUrl:i,message:`No conversation file available to transfer to Claude.`,spokenText:`I couldn't find a conversation file to transfer. Please get the chat file first.`};let r=l(e);if(typeof navigator<`u`&&navigator.clipboard)try{await navigator.clipboard.writeText(r)}catch{}return t&&(typeof chrome<`u`&&chrome.tabs?.create?chrome.tabs.create({url:i}):typeof window<`u`&&window.open(i,`_blank`)),{success:!0,continuationPrompt:r,targetUrl:i,filename:n(e.conversationTitle,e.conversationId),message:`Opened Claude in a new tab. Verified conversation context (${e.messageCount} messages) copied to clipboard.`,spokenText:`Opening a new Claude conversation. Your conversation transcript is prepared and copied to your clipboard so you can paste it directly.`}}var f=new class{container=null;shadow=null;state=`hidden`;statusText=``;recognition=null;isListeningActive=!1;latestExport=null;synth=null;constructor(){typeof window<`u`&&window.speechSynthesis!==void 0&&(this.synth=window.speechSynthesis)}init(){document.getElementById(`beru-assistant-root`)||(this.container=document.createElement(`div`),this.container.id=`beru-assistant-root`,this.container.style.cssText=`position: fixed; z-index: 2147483647; bottom: 24px; right: 24px; pointer-events: none;`,this.shadow=this.container.attachShadow({mode:`open`}),this.render(),document.body.appendChild(this.container),typeof chrome<`u`&&chrome.runtime?.onMessage&&chrome.runtime.onMessage.addListener((e,t,n)=>{e?.action===`TOGGLE_BERU`?(this.toggleListening(),n({success:!0,state:this.state})):e?.action===`EXECUTE_COMMAND`&&(this.handleCommand(e.command),n({success:!0}))}),typeof chrome<`u`&&chrome.storage?.local&&chrome.storage.local.get([`beruContinuousListening`],e=>{e.beruContinuousListening&&this.startListening()}))}render(){if(!this.shadow)return;let e=this.state!==`hidden`;this.container.style.pointerEvents=e?`auto`:`none`,this.shadow.innerHTML=`
      <style>
        :host {
          all: initial;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }

        .beru-wrapper {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 10px;
          transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
          opacity: ${e?`1`:`0`};
          transform: ${e?`translateY(0) scale(1)`:`translateY(20px) scale(0.85)`};
          pointer-events: ${e?`auto`:`none`};
        }

        /* Siri-like Floating Orb */
        .beru-orb-container {
          position: relative;
          width: 58px;
          height: 58px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }

        .beru-orb {
          width: 52px;
          height: 52px;
          border-radius: 50%;
          background: radial-gradient(circle at 35% 35%, #38bdf8 0%, #6366f1 45%, #ec4899 75%, #0f172a 100%);
          box-shadow: 0 4px 24px rgba(99, 102, 241, 0.45), 0 0 12px rgba(56, 189, 248, 0.5);
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: transform 0.25s ease, box-shadow 0.25s ease;
          animation: beru-glow 3s infinite alternate ease-in-out;
        }

        .beru-orb:hover {
          transform: scale(1.06);
          box-shadow: 0 6px 30px rgba(99, 102, 241, 0.65), 0 0 18px rgba(236, 72, 153, 0.6);
        }

        .beru-orb::after {
          content: "";
          position: absolute;
          inset: 2px;
          border-radius: 50%;
          border: 1.5px solid rgba(255, 255, 255, 0.3);
          pointer-events: none;
        }

        /* Pulsing Aura Ring */
        .beru-ring {
          position: absolute;
          inset: -4px;
          border-radius: 50%;
          border: 2px solid transparent;
          border-top-color: #38bdf8;
          border-right-color: #ec4899;
          border-bottom-color: #a855f7;
          pointer-events: none;
          opacity: 0.8;
          animation: beru-spin 2s linear infinite;
        }

        /* Dynamic State Variations */
        .state-listening .beru-orb {
          animation: beru-pulse-listening 1.3s infinite ease-in-out;
          box-shadow: 0 0 28px rgba(56, 189, 248, 0.7);
        }

        .state-processing .beru-orb {
          background: radial-gradient(circle at 35% 35%, #fbbf24 0%, #3b82f6 50%, #8b5cf6 100%);
          animation: beru-spin 1.5s linear infinite;
        }

        .state-speaking .beru-orb {
          background: radial-gradient(circle at 35% 35%, #10b981 0%, #3b82f6 60%, #6366f1 100%);
          animation: beru-pulse-speaking 0.9s infinite alternate;
        }

        .state-success .beru-orb {
          background: radial-gradient(circle at 35% 35%, #10b981 0%, #059669 80%, #064e3b 100%);
          box-shadow: 0 0 28px rgba(16, 185, 129, 0.8);
        }

        .state-error .beru-orb {
          background: radial-gradient(circle at 35% 35%, #ef4444 0%, #b91c1c 80%, #7f1d1d 100%);
          box-shadow: 0 0 28px rgba(239, 68, 68, 0.8);
        }

        /* Floating Pill Banner */
        .beru-pill {
          background: rgba(15, 23, 42, 0.92);
          backdrop-filter: blur(12px);
          -webkit-backdrop-filter: blur(12px);
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 20px;
          padding: 8px 14px;
          color: #f8fafc;
          font-size: 12px;
          font-weight: 500;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.35);
          display: flex;
          align-items: center;
          gap: 8px;
          max-width: 280px;
          line-height: 1.35;
        }

        .beru-icon {
          font-size: 14px;
        }

        .beru-close {
          background: transparent;
          border: none;
          color: #94a3b8;
          font-size: 14px;
          cursor: pointer;
          padding: 0 2px;
          line-height: 1;
        }

        .beru-close:hover {
          color: #f8fafc;
        }

        @keyframes beru-glow {
          0% { transform: scale(1); filter: brightness(1); }
          100% { transform: scale(1.03); filter: brightness(1.15); }
        }

        @keyframes beru-spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        @keyframes beru-pulse-listening {
          0% { transform: scale(0.96); box-shadow: 0 0 16px rgba(56, 189, 248, 0.4); }
          50% { transform: scale(1.06); box-shadow: 0 0 32px rgba(56, 189, 248, 0.8), 0 0 45px rgba(236, 72, 153, 0.5); }
          100% { transform: scale(0.96); box-shadow: 0 0 16px rgba(56, 189, 248, 0.4); }
        }

        @keyframes beru-pulse-speaking {
          0% { transform: scale(0.97); }
          100% { transform: scale(1.05); }
        }
      </style>

      <div class="beru-wrapper state-${this.state}">
        ${this.statusText?`
          <div class="beru-pill">
            <span class="beru-icon">${this.getStatusIcon()}</span>
            <span>${this.statusText}</span>
            <button class="beru-close" id="beru-dismiss" title="Dismiss">✕</button>
          </div>
        `:``}
        <div class="beru-orb-container" id="beru-orb-btn" title="BERU Assistant (Click to Stop)">
          <div class="beru-ring"></div>
          <div class="beru-orb">
            <span style="font-size: 18px; filter: drop-shadow(0 1px 2px rgba(0,0,0,0.5));">🎙</span>
          </div>
        </div>
      </div>
    `,this.shadow.getElementById(`beru-orb-btn`)?.addEventListener(`click`,()=>{this.toggleListening()}),this.shadow.getElementById(`beru-dismiss`)?.addEventListener(`click`,()=>{this.setState(`hidden`,``)})}getStatusIcon(){switch(this.state){case`listening`:return`🔴`;case`processing`:return`⏳`;case`speaking`:return`🔊`;case`success`:return`✓`;case`error`:return`⚠️`;default:return`🎙`}}setState(e,t=``){this.state=e,this.statusText=t,this.render()}toggleListening(){this.isListeningActive?this.stopListening():this.startListening()}startListening(){let e=window,t=e.SpeechRecognition||e.webkitSpeechRecognition;if(!t){this.setState(`error`,`SpeechRecognition unavailable in this browser.`);return}try{this.recognition=new t,this.recognition.lang=`en-US`,this.recognition.continuous=!0,this.recognition.interimResults=!1,this.recognition.onresult=e=>{let t=e.results.length-1,n=e.results[t][0]?.transcript||``;n.trim()&&this.handleCommand(n.trim())},this.recognition.onerror=e=>{e.error===`not-allowed`?(this.setState(`error`,`Microphone access blocked. Click extension icon to grant.`),this.isListeningActive=!1):e.error!==`no-speech`&&this.setState(`error`,`Mic error: ${e.error}`)},this.recognition.onend=()=>{if(this.isListeningActive)try{this.recognition.start()}catch{this.isListeningActive=!1,this.setState(`hidden`)}},this.recognition.start(),this.isListeningActive=!0,this.setState(`listening`,`Listening for "Hey Beru"…`)}catch{this.setState(`error`,`Could not start microphone.`),this.isListeningActive=!1}}stopListening(){if(this.isListeningActive=!1,this.recognition){try{this.recognition.abort()}catch{}this.recognition=null}this.setState(`hidden`,``)}speak(e,t){if(!this.synth){t&&t();return}this.synth.cancel();let n=new SpeechSynthesisUtterance(e);n.rate=1,n.pitch=1,n.onstart=()=>{this.setState(`speaking`,e)},n.onend=()=>{t?t():this.isListeningActive?this.setState(`listening`,`Listening for "Hey Beru"…`):setTimeout(()=>this.setState(`hidden`,``),3e3)},this.synth.speak(n)}async handleCommand(e){switch(c(e).type){case`wake_word`:this.setState(`listening`,`I'm listening…`),this.speak(`I'm listening.`);break;case`get_chat_file`:this.setState(`processing`,`Retrieving chat transcript…`),this.speak(`Preparing your conversation file.`,async()=>{let e=u(this.extractCurrentChatGPTConversation(),!0);e.success&&e.exportData?(this.latestExport=e.exportData,this.setState(`success`,`Downloaded: ${e.filename}`),this.speak(e.spokenText)):(this.setState(`error`,e.message),this.speak(e.spokenText))});break;case`transfer_to_claude`:this.setState(`processing`,`Preparing transfer to Claude…`),this.speak(`Opening Claude and transferring context.`,async()=>{let e=this.latestExport;if(!e){let t=u(this.extractCurrentChatGPTConversation(),!1);t.success&&t.exportData&&(e=t.exportData,this.latestExport=e)}if(e){let t=await d(e,!0);this.setState(`success`,`Transferred! Paste (Ctrl+V) in Claude.`),this.speak(t.spokenText)}else this.setState(`error`,`No active conversation found to transfer.`),this.speak(`I couldn't find a conversation to transfer.`)});break;case`stop_listening`:this.stopListening(),this.speak(`Stopped listening.`)}}extractCurrentChatGPTConversation(){try{let e=document.querySelector(`title`),t=e?e.innerText.replace(/ - ChatGPT.*$/,``).trim():`ChatGPT Conversation`,n=document.querySelectorAll(`article[data-testid^="conversation-turn-"], div[data-message-author-role]`);if(!n||n.length===0)return null;let r=[],i=1;return n.forEach(e=>{let t=e.getAttribute(`data-message-author-role`)===`assistant`||e.querySelector(`[data-message-author-role="assistant"]`)!==null?`assistant`:`user`,n=e.innerText?.trim();n&&r.push({id:`msg-${i}`,sequence:i++,role:t,content:n,timestamp:new Date().toISOString()})}),r.length===0?null:{id:`chatgpt-live-session`,platform:`chatgpt`,title:t||`ChatGPT Conversation`,url:window.location.href,messages:r,state:`completed`,hasMoreHistory:!1,isComplete:!0,completenessStatus:`complete`,capturedAt:new Date().toISOString(),lastCheckpointAt:new Date().toISOString()}}catch{return null}}};document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,()=>f.init()):f.init();})()
