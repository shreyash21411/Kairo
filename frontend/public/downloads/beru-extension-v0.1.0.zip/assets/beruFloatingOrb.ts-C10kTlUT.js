import{n as e,t}from"./beruVoiceCommands-BlwYT4po.js";var n=new class{container=null;shadow=null;state=`hidden`;statusText=``;latestExport=null;synth=null;autoHideTimer=null;constructor(){typeof window<`u`&&window.speechSynthesis!==void 0&&(this.synth=window.speechSynthesis)}init(){document.getElementById(`beru-assistant-root`)||(this.container=document.createElement(`div`),this.container.id=`beru-assistant-root`,this.container.style.cssText=`position: fixed; z-index: 2147483647; bottom: 24px; right: 24px; pointer-events: none;`,this.shadow=this.container.attachShadow({mode:`open`}),this.render(),document.body.appendChild(this.container),typeof chrome<`u`&&chrome.runtime?.onMessage&&chrome.runtime.onMessage.addListener((e,t,n)=>e?.action===`WAKE_UP`?(this.wakeUp(),n({success:!0,state:this.state}),!0):e?.action===`WAKE_OFF`?(this.hide(),n({success:!0}),!0):e?.action===`EXECUTE_INTENT`?(this.handleIntent(e.intent),n({success:!0}),!0):e?.action===`TOGGLE_BERU`&&(this.toggleAssistant(),n({success:!0,state:this.state}),!0)))}wakeUp(){this.clearAutoHide(),this.setState(`listening`,`I'm listening…`),this.speak(`I'm listening.`)}hide(){this.clearAutoHide(),this.synth&&this.synth.cancel(),this.setState(`hidden`,``)}toggleAssistant(){this.state===`hidden`?this.wakeUp():this.hide()}clearAutoHide(){this.autoHideTimer!==null&&(clearTimeout(this.autoHideTimer),this.autoHideTimer=null)}scheduleAutoHide(e=3500){this.clearAutoHide(),this.autoHideTimer=window.setTimeout(()=>{this.hide()},e)}setState(e,t=``){this.state=e,this.statusText=t,this.render(),typeof chrome<`u`&&chrome.runtime?.sendMessage&&chrome.runtime.sendMessage({type:`ASSISTANT_STATE_UPDATE`,state:e===`hidden`?`idle`:e}).catch(()=>{})}render(){if(!this.shadow)return;let e=this.state!==`hidden`;this.container.style.pointerEvents=e?`auto`:`none`,this.shadow.innerHTML=`
      <style>
        :host {
          all: initial;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }

        .beru-wrapper {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 12px;
          transition: opacity 0.28s cubic-bezier(0.16, 1, 0.3, 1), transform 0.28s cubic-bezier(0.16, 1, 0.3, 1);
          opacity: ${e?`1`:`0`};
          transform: ${e?`translateY(0) scale(1)`:`translateY(16px) scale(0.9)`};
          pointer-events: ${e?`auto`:`none`};
        }

        /* Siri-like Floating Orb */
        .beru-orb-container {
          position: relative;
          width: 56px;
          height: 56px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
        }

        .beru-orb {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background: radial-gradient(circle at 35% 35%, #38bdf8 0%, #6366f1 45%, #ec4899 75%, #0b0f19 100%);
          box-shadow: 0 4px 20px rgba(99, 102, 241, 0.4), 0 0 16px rgba(56, 189, 248, 0.5);
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: transform 0.2s ease, box-shadow 0.2s ease;
          animation: beru-breathe 2.8s infinite alternate ease-in-out;
        }

        .beru-orb:hover {
          transform: scale(1.06);
          box-shadow: 0 6px 24px rgba(99, 102, 241, 0.6), 0 0 20px rgba(236, 72, 153, 0.6);
        }

        /* Spinning Aura Ring */
        .beru-aura {
          position: absolute;
          inset: -4px;
          border-radius: 50%;
          background: conic-gradient(from 0deg, #38bdf8, #818cf8, #f472b6, #38bdf8);
          opacity: 0.6;
          filter: blur(4px);
          animation: beru-spin 3s linear infinite;
          z-index: -1;
        }

        @keyframes beru-spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        @keyframes beru-breathe {
          0% {
            transform: scale(0.97);
            box-shadow: 0 4px 16px rgba(99, 102, 241, 0.4), 0 0 12px rgba(56, 189, 248, 0.4);
          }
          100% {
            transform: scale(1.03);
            box-shadow: 0 8px 28px rgba(99, 102, 241, 0.65), 0 0 24px rgba(244, 114, 182, 0.7);
          }
        }

        /* Status Toast Pill */
        .beru-toast {
          background: rgba(11, 14, 22, 0.88);
          backdrop-filter: blur(14px);
          -webkit-backdrop-filter: blur(14px);
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 20px;
          padding: 8px 16px;
          color: #f3f4f6;
          font-size: 13px;
          font-weight: 500;
          display: flex;
          align-items: center;
          gap: 8px;
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
          max-width: 280px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .beru-status-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: ${this.getStatusDotColor()};
          box-shadow: 0 0 8px ${this.getStatusDotColor()};
          animation: ${this.state===`listening`?`beru-pulse-dot 1.2s infinite`:`none`};
        }

        @keyframes beru-pulse-dot {
          0%, 100% { transform: scale(0.9); opacity: 0.8; }
          50% { transform: scale(1.25); opacity: 1; }
        }

        .beru-close-btn {
          background: transparent;
          border: none;
          color: #94a3b8;
          cursor: pointer;
          font-size: 12px;
          padding: 2px 4px;
          margin-left: 4px;
          line-height: 1;
        }

        .beru-close-btn:hover {
          color: #fff;
        }
      </style>

      <div class="beru-wrapper">
        ${this.statusText?`
          <div class="beru-toast">
            <div class="beru-status-dot"></div>
            <span>${this.statusText}</span>
            <button class="beru-close-btn" id="beru-dismiss" title="Dismiss">✕</button>
          </div>
        `:``}
        <div class="beru-orb-container" id="beru-orb-btn" title="BERU Assistant (Click to dismiss)">
          <div class="beru-aura"></div>
          <div class="beru-orb">
            <span style="font-size: 16px; filter: drop-shadow(0 1px 2px rgba(0,0,0,0.5));">${this.getStatusIcon()}</span>
          </div>
        </div>
      </div>
    `,this.shadow.getElementById(`beru-orb-btn`)?.addEventListener(`click`,()=>{this.hide()}),this.shadow.getElementById(`beru-dismiss`)?.addEventListener(`click`,()=>{this.hide()})}getStatusDotColor(){switch(this.state){case`listening`:return`#38bdf8`;case`processing`:return`#fbbf24`;case`speaking`:return`#c084fc`;case`success`:return`#34d399`;case`error`:return`#f87171`;default:return`#94a3b8`}}getStatusIcon(){switch(this.state){case`listening`:return`🎙️`;case`processing`:return`⏳`;case`speaking`:return`🔊`;case`success`:return`✓`;case`error`:return`⚠️`;default:return`✦`}}speak(e,t){if(!this.synth){t&&t();return}this.synth.cancel();let n=new SpeechSynthesisUtterance(e);n.rate=1.05,n.pitch=1,n.onstart=()=>{this.setState(`speaking`,e)},n.onend=()=>{t?t():this.scheduleAutoHide(3e3)},this.synth.speak(n)}async handleIntent(n){if(n)switch(n.type){case`wake_word`:this.wakeUp();break;case`get_chat_file`:this.clearAutoHide(),this.setState(`processing`,`Retrieving chat transcript…`),this.speak(`Preparing your conversation file.`,async()=>{let e=this.extractCurrentChatGPTConversation(),n=t(e,!0);n.success&&n.exportData?(this.latestExport=n.exportData,this.setState(`success`,`Downloaded: ${n.filename}`),this.speak(n.spokenText)):(this.setState(`error`,n.message),this.speak(n.spokenText))});break;case`transfer_to_claude`:this.clearAutoHide(),this.setState(`processing`,`Preparing transfer to Claude…`),this.speak(`Opening Claude and transferring context.`,async()=>{let n=this.latestExport;if(!n){let e=this.extractCurrentChatGPTConversation(),r=t(e,!1);r.success&&r.exportData&&(n=r.exportData,this.latestExport=n)}if(n){let t=await e(n,!0);this.setState(`success`,`Transferred! Paste (Ctrl+V) in Claude.`),this.speak(t.spokenText)}else this.setState(`error`,`No active conversation found to transfer.`),this.speak(`I couldn't find a conversation to transfer.`)});break;case`stop_listening`:this.hide(),this.speak(`Stopped listening.`)}}extractCurrentChatGPTConversation(){try{let e=document.querySelector(`title`),t=e?e.innerText.replace(/ - ChatGPT.*$/,``).trim():`ChatGPT Conversation`,n=document.querySelectorAll(`article[data-testid^="conversation-turn-"], div[data-message-author-role]`);if(!n||n.length===0)return null;let r=[],i=1;return n.forEach(e=>{let t=e.getAttribute(`data-message-author-role`)===`assistant`||e.querySelector(`[data-message-author-role="assistant"]`)!==null?`assistant`:`user`,n=e.innerText?.trim();n&&r.push({id:`msg-${i}`,sequence:i++,role:t,content:n,timestamp:new Date().toISOString()})}),r.length===0?null:{id:`chatgpt-live-session`,platform:`chatgpt`,title:t||`ChatGPT Conversation`,url:window.location.href,messages:r,state:`completed`,hasMoreHistory:!1,isComplete:!0,completenessStatus:`complete`,capturedAt:new Date().toISOString(),lastCheckpointAt:new Date().toISOString()}}catch{return null}}};document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,()=>n.init()):n.init();